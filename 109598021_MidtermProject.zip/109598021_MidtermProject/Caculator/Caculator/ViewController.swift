//
//  ViewController.swift
//  Caculator
//
//  Created by Bonnie on 2021/3/8.
//

import UIKit

extension NSExpression {

    func toFloatingPoint() -> NSExpression {
        switch expressionType {
        case .constantValue:
            if let value = constantValue as? NSNumber {
                return NSExpression(forConstantValue: NSNumber(value: value.doubleValue))
            }
        case .function:
           let newArgs = arguments.map { $0.map { $0.toFloatingPoint() } }
           return NSExpression(forFunction: operand, selectorName: function, arguments: newArgs)
        case .conditional:
           return NSExpression(forConditional: predicate, trueExpression: self.true.toFloatingPoint(), falseExpression: self.false.toFloatingPoint())
        case .unionSet:
            return NSExpression(forUnionSet: left.toFloatingPoint(), with: right.toFloatingPoint())
        case .intersectSet:
            return NSExpression(forIntersectSet: left.toFloatingPoint(), with: right.toFloatingPoint())
        case .minusSet:
            return NSExpression(forMinusSet: left.toFloatingPoint(), with: right.toFloatingPoint())
        case .subquery:
            if let subQuery = collection as? NSExpression {
                return NSExpression(forSubquery: subQuery.toFloatingPoint(), usingIteratorVariable: variable, predicate: predicate)
            }
        case .aggregate:
            if let subExpressions = collection as? [NSExpression] {
                return NSExpression(forAggregate: subExpressions.map { $0.toFloatingPoint() })
            }
        case .anyKey:
            fatalError("anyKey not yet implemented")
        case .block:
            fatalError("block not yet implemented")
        case .evaluatedObject, .variable, .keyPath:
            break // Nothing to do here
        }
        return self
    }
}


class ViewController: UIViewController {
    var varNumber1 = 0
    var varNumber2 = 0
    var varNumberResult = 0
    var varOperator = "+"
    var startNew = true
    var isDecimal = false
    var useOperator = false
    
    var calculate:calculate?
    
    @IBOutlet weak var resultTextField: UITextField!
    @IBOutlet weak var processLabel: UILabel!
    
    @IBAction func button0(_ sender: Any) {
        if(self.startNew == false){
            resultTextField.text = resultTextField.text! + "0"
        }
    }
    
    @IBAction func button1(_ sender: Any) {
        if(self.startNew == true){
            resultTextField.text = ""
            self.startNew = false
        }
        resultTextField.text = resultTextField.text! + "1"
    }
    
    @IBAction func button2(_ sender: Any) {
        if(self.startNew == true){
            resultTextField.text = ""
            self.startNew = false
        }
        resultTextField.text = resultTextField.text! + "2"
    }
    
    @IBAction func button3(_ sender: Any) {
        if(self.startNew == true){
            resultTextField.text = ""
            self.startNew = false
        }
        resultTextField.text = resultTextField.text! + "3"
    }
    
    @IBAction func button4(_ sender: Any) {
        if(self.startNew == true){
            resultTextField.text = ""
            self.startNew = false
        }
        resultTextField.text = resultTextField.text! + "4"
    }
    
    @IBAction func button5(_ sender: Any) {
        if(self.startNew == true){
            resultTextField.text = ""
            self.startNew = false
        }
        resultTextField.text = resultTextField.text! + "5"
    }
    
    @IBAction func button6(_ sender: Any) {
        if(self.startNew == true){
            resultTextField.text = ""
            self.startNew = false
        }
        resultTextField.text = resultTextField.text! + "6"
    }
    
    @IBAction func button7(_ sender: Any) {
        if(self.startNew == true){
            resultTextField.text = ""
            self.startNew = false
        }
        resultTextField.text = resultTextField.text! + "7"
    }
    
    @IBAction func button8(_ sender: Any) {
        if(self.startNew == true){
            resultTextField.text = ""
            self.startNew = false
        }
        resultTextField.text = resultTextField.text! + "8"
    }
    
    @IBAction func button9(_ sender: Any) {
        if(self.startNew == true){
            resultTextField.text = ""
            self.startNew = false
        }
        resultTextField.text = resultTextField.text! + "9"
    }
    
    
    @IBAction func buttonDot(_ sender: Any) {
        if(isDecimal == false){
            isDecimal = true
            if(self.startNew == true){
                self.startNew = false
            }
            resultTextField.text = resultTextField.text! + "."
        }
    }
    
    @IBAction func buttonPlus(_ sender: Any) {
        if(self.useOperator == false){
            varOperator = "+"
//            varNumber1 = Int(resultTextField.text!)!
            if(isDecimal == true){
                let result = resultTextField.text!
                let expression = NSExpression(format: result)
                let tmp = expression.toFloatingPoint().expressionValue(with: nil, context: nil) as? Double
                let formatter = NumberFormatter()
                formatter.minimumFractionDigits = 0
                formatter.maximumFractionDigits = 8
                let value = formatter.string(from: NSNumber(value: tmp!))
                resultTextField.text = value! + "+"
                processLabel.text = processLabel.text! + resultTextField.text!
                resultTextField.text = ""
            }
            else{
                resultTextField.text = resultTextField.text! + "+"
//                resultTextField.text = calculate.combine(input1: resultTextField.text!, input2: "+")
                processLabel.text = processLabel.text! + resultTextField.text!
                resultTextField.text = ""
            }
            isDecimal = false
            useOperator = true
        }
        else{
            varOperator = "+"
            var tmp = processLabel.text!
            tmp.removeLast()
            processLabel.text = tmp + "+"
            isDecimal = false
            useOperator = true
        }
    }
    
    @IBAction func buttonMinus(_ sender: Any) {
        if(self.useOperator == false){
            varOperator = "-"
//            varNumber1 = Int(resultTextField.text!)!
            if(isDecimal == true){
                let result = resultTextField.text!
//                print(result)
//                let test = calculate?.cal(input: result)
//                print(test)
                let expression = NSExpression(format: result)
                let tmp = expression.toFloatingPoint().expressionValue(with: nil, context: nil) as? Double
//                print(tmp)
                let formatter = NumberFormatter()
                formatter.minimumFractionDigits = 0
                formatter.maximumFractionDigits = 8
                let value = formatter.string(from: NSNumber(value: tmp!))
//                print(value)
                resultTextField.text = value! + "-"
                processLabel.text = processLabel.text! + resultTextField.text!
                resultTextField.text = ""
            }
            else{
                resultTextField.text = resultTextField.text! + "-"
                processLabel.text = processLabel.text! + resultTextField.text!
                resultTextField.text = ""
            }
            isDecimal = false
            useOperator = true
        }
        else{
            varOperator = "-"
            var tmp = processLabel.text!
            tmp.removeLast()
            processLabel.text = tmp + "-"
            isDecimal = false
            useOperator = true
        }
    }
    
    @IBAction func buttonMulti(_ sender: Any) {
        if(self.useOperator == false){
            varOperator = "*"
//            varNumber1 = Int(resultTextField.text!)!
            if(isDecimal == true){
                let result = resultTextField.text!
                let expression = NSExpression(format: result)
                let tmp = expression.toFloatingPoint().expressionValue(with: nil, context: nil) as? Double
                let formatter = NumberFormatter()
                formatter.minimumFractionDigits = 0
                formatter.maximumFractionDigits = 8
                let value = formatter.string(from: NSNumber(value: tmp!))
                resultTextField.text = value! + "*"
                processLabel.text = processLabel.text! + resultTextField.text!
                resultTextField.text = ""
            }
            else{
                resultTextField.text = resultTextField.text! + "*"
                processLabel.text = processLabel.text! + resultTextField.text!
                resultTextField.text = ""
            }
            isDecimal = false
            useOperator = true
        }
        else{
            varOperator = "*"
            var tmp = processLabel.text!
            tmp.removeLast()
            processLabel.text = tmp + "*"
            isDecimal = false
            useOperator = true
        }
    }
    
    @IBAction func buttonDivision(_ sender: Any) {
        if(self.useOperator == false){
            varOperator = "/"
//            varNumber1 = Int(resultTextField.text!)!
            if(isDecimal == true){
                let result = resultTextField.text!
                let expression = NSExpression(format: result)
                let tmp = expression.toFloatingPoint().expressionValue(with: nil, context: nil) as? Double
                let formatter = NumberFormatter()
                formatter.minimumFractionDigits = 0
                formatter.maximumFractionDigits = 8
                let value = formatter.string(from: NSNumber(value: tmp!))
                resultTextField.text = value! + "/"
                processLabel.text = processLabel.text! + resultTextField.text!
                resultTextField.text = ""
            }
            else{
                resultTextField.text = resultTextField.text! + "/"
                processLabel.text = processLabel.text! + resultTextField.text!
                resultTextField.text = ""
            }
            isDecimal = false
            useOperator = true
        }
        else{
            varOperator = "/"
            var tmp = processLabel.text!
            tmp.removeLast()
            processLabel.text = tmp + "/"
            isDecimal = false
            useOperator = true
        }
    }
    
    @IBAction func buttonPercent(_ sender: Any) {
        varOperator = "%"
        let tmp = resultTextField.text! + "/100"
        let expression = NSExpression(format: tmp)
        if(isDecimal == true){
            let result = resultTextField.text!
            let expression = NSExpression(format: result)
            let tmp = expression.toFloatingPoint().expressionValue(with: nil, context: nil) as? Double
            let formatter = NumberFormatter()
            formatter.minimumFractionDigits = 0
            formatter.maximumFractionDigits = 8
            let value = formatter.string(from: NSNumber(value: tmp!))
            resultTextField.text = value! + "%="
            processLabel.text = processLabel.text! + resultTextField.text!
            resultTextField.text = ""
        }
        else{
            processLabel.text = resultTextField.text! + "%="
        }
        let result =  expression.toFloatingPoint().expressionValue(with: nil, context: nil) as? Double
        let formatter = NumberFormatter()
        formatter.minimumFractionDigits = 0
        formatter.maximumFractionDigits = 8
        resultTextField.text = formatter.string(from: NSNumber(value: result!))
        isDecimal = false
        useOperator = false
    }
    
    
    @IBAction func buttonNegative(_ sender: Any) {
        varOperator = "±"
        let tmp = "0-" + resultTextField.text!
        let expression = NSExpression(format: tmp)
        if(isDecimal == true){
            let result = resultTextField.text!
            let expression = NSExpression(format: result)
            let tmp = expression.toFloatingPoint().expressionValue(with: nil, context: nil) as? Double
            let formatter = NumberFormatter()
            formatter.minimumFractionDigits = 0
            formatter.maximumFractionDigits = 8
            let value = formatter.string(from: NSNumber(value: tmp!))
//            resultTextField.text = value! + "%="
//            processLabel.text = processLabel.text! + resultTextField.text!
            processLabel.text = "±( " + value! + " )="
            resultTextField.text = ""
        }
        else{
            processLabel.text = "±( " + resultTextField.text! + " )="
        }
        let result =  expression.toFloatingPoint().expressionValue(with: nil, context: nil) as? Double
        let formatter = NumberFormatter()
        formatter.minimumFractionDigits = 0
        formatter.maximumFractionDigits = 8
        resultTextField.text = formatter.string(from: NSNumber(value: result!))
        isDecimal = false
        useOperator = false
    }
    
    @IBAction func buttonEqual(_ sender: Any) {
        useOperator = false
        if(isDecimal == true){
            let resultP = resultTextField.text!
            let expressionP = NSExpression(format: resultP)
            let tmp = expressionP.toFloatingPoint().expressionValue(with: nil, context: nil) as? Double
            let formatterP = NumberFormatter()
            formatterP.minimumFractionDigits = 0
            formatterP.maximumFractionDigits = 8
            let valueP = formatterP.string(from: NSNumber(value: tmp!))
            resultTextField.text = valueP!
            
            let process = processLabel.text! + resultTextField.text!
            let expression = NSExpression(format: process)
            let result = expression.toFloatingPoint().expressionValue(with: nil, context: nil) as? Double
//            print(result!)
            let formatter = NumberFormatter()
            formatter.minimumFractionDigits = 0
            formatter.maximumFractionDigits = 8
            var value = formatter.string(from: NSNumber(value: result!))
            resultTextField.text = resultTextField.text! + "="
            processLabel.text = processLabel.text! + resultTextField.text!
            if(value! == "-∞" || value! == "+∞"){
                value! = "0"
            }
            resultTextField.text = value//result
        }
        else{
            let process = processLabel.text! + resultTextField.text!
            let expression = NSExpression(format: process)
            let result = expression.toFloatingPoint().expressionValue(with: nil, context: nil) as? Double
//            print(result!)
            let formatter = NumberFormatter()
            formatter.minimumFractionDigits = 0
            formatter.maximumFractionDigits = 8
            var value = formatter.string(from: NSNumber(value: result!))
            resultTextField.text = resultTextField.text! + "="
            processLabel.text = processLabel.text! + resultTextField.text!
            if(value! == "-∞" || value! == "+∞"){
                value! = "0"
            }
            resultTextField.text = value//result
        }
    }
    
    @IBAction func buttonClear(_ sender: Any) {
        self.startNew = true
        self.isDecimal = false
        self.useOperator = false
        resultTextField.text = "0"
        processLabel.text = ""
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

