//
//  calculate.swift
//  Caculator
//
//  Created by Bonnie on 2021/4/27.
//

import Foundation

class calculate{
    
    func cal(input: String) -> String{
        let expression = NSExpression(format: input)
        let tmp = expression.toFloatingPoint().expressionValue(with: nil, context: nil) as? Double
        let formatter = NumberFormatter()
        formatter.minimumFractionDigits = 0
        formatter.maximumFractionDigits = 8
        let output = formatter.string(from: NSNumber(value: tmp!))
//        print(output)
        return output!
    }
    
    func combine(input1: String, input2: String) -> String{
        return input1 + input2
    }
    
}
