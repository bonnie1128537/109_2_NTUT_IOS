//
//  CivetCatView.swift
//  Demo
//
//  Created by Bonnie on 2021/5/3.
//

import SwiftUI

struct CivetCatView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
            .navigationTitle("小狸貓")
    }
}

struct CivetCatView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView {
            CivetCatView()
        }
    }
}
