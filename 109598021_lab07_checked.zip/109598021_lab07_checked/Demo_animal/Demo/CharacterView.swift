//
//  CharacterView.swift
//  Demo
//
//  Created by Bonnie on 2021/5/5.
//

import SwiftUI

struct CharacterView: View {
    let intro = ["小狸貓。", "非常悠閒，大多時候有點草率，和許多朋友一起住在山裡。最喜歡和小狐狸玩，也最喜歡吃東西。", "小狐狸。", "喜歡捉弄小狸貓。不討厭和小狸貓玩，但是不會說出來。", "我行我素的小狸貓，和愛唱反調的小狐狸，每天都在山裡到處玩耍。有時候會吵架，但是很快就和好了。"]
    
    var body: some View {
        VStack {
            Image("animal2")
                .resizable()
                .scaledToFit()
            ForEach(intro.indices) { index in
               Text(intro[index])
            }
            .navigationTitle("角色介紹")
        }
    }
}

struct CharacterView_Previews: PreviewProvider {
    static var previews: some View {
        CharacterView()
    }
}
