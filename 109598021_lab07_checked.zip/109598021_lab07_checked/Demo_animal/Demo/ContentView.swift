//
//  ContentView.swift
//  Demo
//
//  Created by Bonnie on 2021/4/26.
//

import SwiftUI

struct ContentView: View {
    @State private var number = 1
    @State var showPreviewPage = false
    
    var body: some View {
        NavigationView {
            VStack{
//                CircleImage(pictureName: "animal")
                Image("CivetCatAndFox")
                    .resizable()
                    .scaledToFit()
//                Button(action: {
//                    showPreviewPage = true
//                }, label: {
//                    Text("ShowPreviewPage")
//                })
//                    .sheet(isPresented: $showPreviewPage, content: {
//                        PreviewView(showPreviewPage:$showPreviewPage)
//                    })
                NavigationLink(
                    destination: CharacterView(),
                    label: {
                        Text("角色介紹")
                    })
                NavigationLink(
                    destination: StoryView(),
                    label: {
                        Text("故事介紹")
                    })
            }
            .navigationTitle("小狸貓與小狐狸")
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

struct CircleImage: View {
    let pictureName:String
    var body: some View {
        Image(pictureName)
            .resizable()
            .scaledToFit()
            .clipShape(Circle())
            .shadow(radius: /*@START_MENU_TOKEN@*/10/*@END_MENU_TOKEN@*/ )
            .frame(width: 200, height: 200, alignment: .center)
    }
}
