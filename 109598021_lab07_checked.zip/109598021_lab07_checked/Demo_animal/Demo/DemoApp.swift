//
//  DemoApp.swift
//  Demo
//
//  Created by Bonnie on 2021/4/26.
//

import SwiftUI

@main
struct DemoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
