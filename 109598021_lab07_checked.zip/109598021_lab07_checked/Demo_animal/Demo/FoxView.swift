//
//  FoxView.swift
//  Demo
//
//  Created by Bonnie on 2021/5/5.
//

import SwiftUI

struct FoxView: View {
    var body: some View {
        Text("Hello, World!Fox")
            .navigationTitle("小狐狸")
    }
}

struct FoxView_Previews: PreviewProvider {
    static var previews: some View {
        FoxView()
    }
}
