//
//  StoryView.swift
//  Demo
//
//  Created by Bonnie on 2021/5/5.
//

import SwiftUI

struct StoryView: View {
    let story = ["小狸貓救了在狸貓山迷路的小狐狸之後，兩隻成為好友，小狐狸每天都去狸貓山找小狸貓玩，後來懶得每天來回，於是在狸貓山定居下來，偶爾想到才會陪小狸貓玩耍。", "有一天，小狐狸要唸給小狸貓聽的床邊故事是「咔嚓咔嚓山」。", "內容描寫狸貓害死老婆婆，兔子代替老公公教訓狸貓。", "個性傻呼呼的狸貓總是被有點壞心的小狐狸玩弄而渾然不知…。"]
    
    var body: some View {
        VStack {
            Image("animal")
                .resizable()
                .scaledToFit()
            ForEach(story.indices) { index in
               Text(story[index])
            }
            .navigationTitle("故事介紹")
        }
    }
}

struct StoryView_Previews: PreviewProvider {
    static var previews: some View {
        StoryView()
    }
}
