//
//  InfoView.swift
//  Demo
//
//  Created by Bonnie on 2021/5/3.
//

import SwiftUI

struct InfoView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct InfoView_Previews: PreviewProvider {
    static var previews: some View {
        InfoView()
    }
}
