//
//  MVVM_jankenGameApp.swift
//  MVVM_jankenGame
//
//  Created by Bonnie on 2021/5/19.
//

import SwiftUI

@main
struct MVVM_jankenGameApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
