//
//  Choice.swift
//  MVVM_jankenGame
//
//  Created by Bonnie on 2021/5/19.
//

import Foundation

struct Choice {
    var operation: Operation
    
    enum Operation: String, CaseIterable {
        case paper = "布"
        case scissor = "剪刀"
        case stone = "石頭"
    }
}
