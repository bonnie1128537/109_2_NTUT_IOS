//
//  GameResult.swift
//  MVVM_jankenGame
//
//  Created by Bonnie on 2021/5/19.
//

import Foundation

enum GameResult {
    case win
    case lose
    case tie
}
