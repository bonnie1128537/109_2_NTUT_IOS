//
//  GameViewModel.swift
//  MVVM_jankenGame
//
//  Created by Bonnie on 2021/5/19.
//

import Foundation

class GameViewModel:ObservableObject {
    @Published var player: Choice?
    @Published var computer: Choice?
    @Published var result: GameResult?
    
    func play () {
        playOperation()
//        print(Choice.Operation.allCases.randomElement()!)
        result = playResult()
    }
    
    func playOperation (){
        player = Choice(operation: Choice.Operation.allCases.randomElement()!)
        computer = Choice(operation: Choice.Operation.allCases.randomElement()!)
    }
    
    func playResult () -> GameResult{
        if (computer?.operation == Choice.Operation.scissor && player?.operation == Choice.Operation.stone){
            return .win
        }else if (computer?.operation == Choice.Operation.paper && player?.operation == Choice.Operation.scissor){
            return .win
        }else if (computer?.operation == Choice.Operation.stone && player?.operation == Choice.Operation.paper){
            return .win
        }else if ((computer?.operation == Choice.Operation.stone && player?.operation == Choice.Operation.stone)||(computer?.operation == Choice.Operation.paper && player?.operation == Choice.Operation.paper)||(computer?.operation == Choice.Operation.scissor && player?.operation == Choice.Operation.scissor)){
            return .tie
        }else{
            return .lose
        }
    }
}
