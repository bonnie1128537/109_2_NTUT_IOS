//
//  ContentView.swift
//  MVVM_jankenGame
//
//  Created by Bonnie on 2021/5/19.
//

import SwiftUI

struct ContentView: View {
    @StateObject var gameViewModel = GameViewModel()
//    @StateObject var choice = Choice()
//    @State private var statePlayer = 1
//    @State private var stateComputer = 1
    @State private var result = "請按出拳"
    
    var body: some View {
        VStack{
            Text("猜拳遊戲")
            HStack {
                Text("玩家：")
                Image("\(gameViewModel.player?.operation.rawValue ?? "石頭")")
                    .resizable()
                    .scaledToFit()
                    .frame(width: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/, height: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                Text(gameViewModel.player?.operation.rawValue ?? "石頭")
            }
            HStack {
                Text("電腦：")
                Image("\(gameViewModel.computer?.operation.rawValue ?? "石頭")")
                    .resizable()
                    .scaledToFit()
                    .frame(width: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/, height: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                Text(gameViewModel.computer?.operation.rawValue ?? "石頭")

            }
            Button(action:{
                gameViewModel.play()
                if(gameViewModel.result == .win){
                    result = "獲勝"
                }
                if(gameViewModel.result == .lose){
                    result = "輸了"
                }
                if(gameViewModel.result == .tie){
                    result = "平手"
                }
            }, label:{
                ZStack {
                    Image("猜拳")
                        .resizable()
                        .scaledToFit()
                    Text("出拳！")
                }
            })
            Text("結果： \(result)")
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
